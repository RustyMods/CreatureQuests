## 0.0.1
Beta release
## 0.0.2 
Wrong description on mod, oops
## 0.0.3
- Added tooltip to spawn raven if player has never started any quests
- Added Boar Armor, set effect: trigger transformation into boar, hotkey: G
